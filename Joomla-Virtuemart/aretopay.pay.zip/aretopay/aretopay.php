<?php

/**

 *

 * Paypal payment plugin

 *

 * @author Suraj Sharma

 * @version 1.0

 * @package VirtueMart

 * @subpackage payment

 * Copyright (C) 2004 - 2017 Virtuemart Team. All rights reserved.

 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php

 * VirtueMart is free software. This version may have been modified pursuant

 * to the GNU General Public License, and as distributed it includes or

 * is derivative of works licensed under the GNU General Public License or

 * other free or open source software licenses.

 * See /administrator/components/com_virtuemart/COPYRIGHT.php for copyright notices and details.

 *

 * http://virtuemart.net

 */



defined('_JEXEC') or die('Restricted access');

if (!class_exists ('vmPSPlugin')) {

	require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');

}

if (!class_exists('Areto')) {

	require(VMPATH_ROOT .DS.'plugins'.DS.'vmpayment'.DS.'aretopay'.DS.'areto.php');	

}

require(VMPATH_ROOT .DS.'plugins'.DS.'vmpayment'.DS.'aretopay'.DS.'vendor'.DS.'PHP-Name-Parser'.DS.'parser.php');

require(VMPATH_ROOT .DS.'plugins'.DS.'vmpayment'.DS.'aretopay'.DS.'vendor'.DS.'php-credit-card-validator'.DS.'src'.DS.'CreditCard.php');



class plgVmPaymentAretopay extends vmPSPlugin { 

	 

	private $_cc_name = '';

	private $_cc_type = '';

	private $_cc_number = '';

	private $_cc_cvv = '';

	private $_cc_expire_month = '';

	private $_cc_expire_year = ''; 

	private $_errormessage = array(); 

	public $approved;

	public $declined;

	public $error;

	public $held;



	const APPROVED = 1;

	const DECLINED = 2;

	const ERROR = 3;

	const HELD = 4;



	function __construct(& $subject, $config) { 

		 

		parent::__construct($subject, $config); 

		

		$this->_loggable = TRUE;

		$this->_tablepkey = 'id';

		$this->_tableId = 'id';

		$this->tableFields = array_keys($this->getTableSQLFields());

		$varsToPush = $this->getVarsToPush();

		$this->setConfigParameterable($this->_configTableFieldName, $varsToPush);

	}

	

	

	function getTableSQLFields() {



		$SQLfields = array(

			'id' => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT',

			'virtuemart_order_id' => 'int(1) UNSIGNED',

			'order_number' => 'char(64)',

			'virtuemart_paymentmethod_id' => 'mediumint(1) UNSIGNED',

			'payment_name' => 'varchar(5000)',

			'payment_order_total' => 'decimal(15,5) NOT NULL',

			'payment_currency' => 'smallint(1)',

			'cost_per_transaction' => 'decimal(10,2)',

			'cost_percent_total' => 'char(10)',

			'tax_id' => 'smallint(1)',

			'InternalOrderID' => 'char(255)',

			'aretopay_response_transaction_id' => 'char(128)',

			'aretopay_response_response_code' => 'char(128)'

		);

		return $SQLfields;

	}



	/**

	 * This shows the plugin for choosing in the payment list of the checkout process.

	 *

	 * @author Valerie Cartan Isaksen

	 */

	function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn) {



		if ($this->getPluginMethods($cart->vendorId) === 0) {

			if (empty($this->_name)) {

				$app = JFactory::getApplication();

				$app->enqueueMessage(vmText::_('COM_VIRTUEMART_CART_NO_' . strtoupper($this->_psType)));

				return FALSE;

			} else {

				return FALSE;

			}

		}



		$method_name = $this->_psType . '_name';



		vmLanguage::loadJLang('com_virtuemart', true);

		vmJsApi::jCreditCard();

		$htmla = array();

		$html = '';

		foreach ($this->methods as $this->_currentMethod) {

			if ($this->checkConditions($cart, $this->_currentMethod, $cart->cartPrices)) {

				$cartPrices=$cart->cartPrices;

				$methodSalesPrice = $this->setCartPrices($cart, $cartPrices, $this->_currentMethod);

				$this->_currentMethod->$method_name = $this->renderPluginName($this->_currentMethod);

				$html = $this->getPluginHtml($this->_currentMethod, $selected, $methodSalesPrice); 

				if ($selected == $this->_currentMethod->virtuemart_paymentmethod_id) {

					$this->_getAretopayFromSession();

				} else {

					$this->_cc_name = '';

					$this->_cc_number = '';

					$this->_cc_cvv = '';

					$this->_cc_expire_month = '';

					$this->_cc_expire_year = '';

				}

				

				$html .= '<br /><span class="vmpayment_cardinfo">' . vmText::_('VMPAYMENT_ARETOPAYT_COMPLETE_FORM') . $sandbox_msg . '

		    <table border="0" cellspacing="0" cellpadding="2" width="100%"> 

		    <tr valign="top">

		        <td nowrap width="10%" align="right">

		        	<label for="cc_type">' . vmText::_('VMPAYMENT_ARETOPAY_CCNUM') . '</label>

		        </td>

		        <td>

				 

		        <input type="text" class="inputbox" id="cc_number_aretopay" name="cc_number_aretopay" value="'.$this->_cc_number .'" autocomplete="off" /> 

				</td>

		    </tr>

			<tr valign="top">

		        <td nowrap width="10%" align="right">

		        	<label for="cc_name">' . vmText::_('VMPAYMENT_ARETOPAY_CCNAME') . '</label>

		        </td>

		        <td>

				 

		        <input type="text" class="inputbox" id="cc_name_aretopay" name="cc_name_aretopay" value="'. $this->_cc_name .'" autocomplete="off" /> 

				</td>

		    </tr>

		

		    <tr>

		        <td nowrap width="10%" align="right">' . vmText::_('VMPAYMENT_ARETOPAYT_EXDATE') . '</td>

		        <td> ';

				$html .= shopfunctions::listMonths('cc_expire_month_aretopay', $this->_cc_expire_month); 

				$html .= shopfunctions::listYears('cc_expire_year_aretopay', $this->_cc_expire_year, NULL, null, " ");

				$html .= '</td></tr> 

			<tr valign="top">

		        <td nowrap width="10%" align="right">

		        	<label for="cc_cvv">'. vmText::_('VMPAYMENT_ARETOPAYT_CVV2') . '</label>

		        </td>

		        <td>

		            <input type="text" class="inputbox" id="cc_cvv_aretopay" name="cc_cvv_aretopay" maxlength="4" size="5" value="'. $this->_cc_cvv.'" autocomplete="off" />



			<span class="hasTip" title="' . vmText::_('VMPAYMENT_ARETOPAY_WHATISCVV') . '::' . vmText::sprintf("VMPAYMENT_ARETOPAY_WHATISCVV_TOOLTIP", $cvv_images) . ' ">' .

					vmText::_('VMPAYMENT_ARETOPAY_WHATISCVV') . '

			</span></td>

		    </tr>

			</table></span>'; 

			$htmla[] = $html;

			}

		}

		 

		$htmlIn[] = $htmla;

		return TRUE;

	}

 



	/**

	 * Check if the payment conditions are fulfilled for this payment method

	 *

	 * @author: Valerie Isaksen

	 *

	 * @param $cart_prices: cart prices

	 * @param $payment

	 * @return true: if the conditions are fulfilled, false otherwise

	 *

	 */

	protected function checkConditions($cart, $method, $cart_prices) {

		$this->convert_condition_amount($method);

		$amount = $this->getCartAmount($cart_prices);

		$address = (($cart->ST == 0) ? $cart->BT : $cart->ST);



		$amount_cond = ($amount >= $method->min_amount AND $amount <= $method->max_amount

			OR

			($method->min_amount <= $amount AND ($method->max_amount == 0)));

		if (!$amount_cond) {

			return FALSE;

		} 

		

		$countries = array();

		if (!empty($method->countries)) {

			if (!is_array($method->countries)) {

				$countries[0] = $method->countries;

			} else {

				$countries = $method->countries;

			}

		}



		// probably did not gave his BT:ST address

		if (!is_array($address)) {

			$address = array();

			$address['virtuemart_country_id'] = 0;

		}



		if (!isset($address['virtuemart_country_id'])) {

			$address['virtuemart_country_id'] = 0;

		}

		if (count($countries) == 0 || in_array($address['virtuemart_country_id'], $countries) || count($countries) == 0) {

			return TRUE;

		}



		return FALSE;

	} 



 



	/**

	 * This is for checking the input data of the payment method within the checkout

	 *

	 * @author Valerie Cartan Isaksen

	 */

	function plgVmOnCheckoutCheckDataPayment(VirtueMartCart $cart) {	

		

		if (!$this->selectedThisByMethodId($cart->virtuemart_paymentmethod_id)) {

			return NULL; // Another method was selected, do nothing

		}



		if (!($this->_currentMethod = $this->getVmPluginMethod($cart->virtuemart_paymentmethod_id))) {

			return FALSE;

		} 

		$this->_getAretopayFromSession();

		return $this->_validate_creditcard_aretopay_data(TRUE); 

		

	}



	/**

	 * Create the table for this plugin if it does not yet exist.

	 * This functions checks if the called plugin is active one.

	 * When yes it is calling the standard method to create the tables

	 *

	 */

	function plgVmOnStoreInstallPaymentPluginTable($jplugin_id) { 



		return parent::onStoreInstallPluginTable($jplugin_id);

	}



	/**

	 * This is for adding the input data of the payment method to the cart, after selecting

	 *

	 * @author Valerie Isaksen

	 *

	 * @param VirtueMartCart $cart

	 * @return null if payment not selected; true if card infos are correct; string containing the errors id cc is not valid

	 */

	public function plgVmOnSelectCheckPayment(VirtueMartCart $cart, &$msg) {

		

		if (!$this->selectedThisByMethodId($cart->virtuemart_paymentmethod_id)) {

			return NULL; // Another method was selected, do nothing

		}



		if (!($this->_currentMethod = $this->getVmPluginMethod($cart->virtuemart_paymentmethod_id))) {

			return FALSE;

		} 

		

		

		$this->_cc_name = vRequest::getVar('cc_name_aretopay','');

		$this->_cc_number = str_replace(" ", "", vRequest::getVar('cc_number_aretopay', ''));

		$this->_cc_cvv = vRequest::getVar('cc_cvv_aretopay', '');

		$this->_cc_expire_month = vRequest::getVar('cc_expire_month_aretopay', '');

		$this->_cc_expire_year = vRequest::getVar('cc_expire_year_aretopay', '');

		$this->_setAretopayIntoSession(); 

		if (!$this->_validate_creditcard_aretopay_data(TRUE)) {			

			return FALSE; 

		} 

		

		return TRUE;

	}

	

	function _validate_creditcard_aretopay_data($enqueueMessage = TRUE) {

	

		static $force=true;

		if(empty($this->_cc_number) and empty($this->_cc_cvv)){

			return false;

		}

		$html = '';

		$this->_cc_valid = true; 

		

		if (!empty($this->_cc_number) and !$this->validate_credit_card_number_aretopay($this->_cc_number)) {

			$this->_errormessage[] = 'VMPAYMENT_ARETOPAY_CARD_NUMBER_INVALID';

			$this->_cc_valid = FALSE;

		} 

		

		if (!$this->_cc_valid) { 

			foreach ($this->_errormessage as $msg) {

				$html .= vmText::_($msg) . "<br/>";

			}

		}

		if (!$this->_cc_valid && $enqueueMessage && $force) {

			vmWarn($html);

			$force=false;

		}

		return $this->_cc_valid;

	} 

	

	function validate_credit_card_number_aretopay($no){

		$card = Inacho\CreditCard::validCreditCard($no);

		if (!$card['valid']) {

			return false;

		}else{

			return $card;

		}

	}

	

	function _card_type($card){

		 $types = array(

			'visaelectron' => 'VisaElectron',

			'maestro' => 'MAES',

			'visa' => 'VISA',

			'mastercard' => 'MC',

			'amex' => 'AMEX',

			'dinersclub' => 'DINER',

			'discover' => 'DISC',

			'unionpay' => 'CUP',

			'jcb' => 'JCB',

		);

		$type = isset($types[$card['type']]) ? $types[$card['type']] : strtoupper($card['type']);

		return $type;

	}

	

	

	function _parse_name_field($name){

		$parser = new FullNameParser();

		$parsefields = $parser->parse_name($name);

		return $parsefields;

	}



	public function plgVmOnSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$payment_name) {



		if (!($this->_currentMethod = $this->getVmPluginMethod($cart->virtuemart_paymentmethod_id))) {

			return NULL; // Another method was selected, do nothing

		}

		if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {

			return FALSE;

		}

		

		$this->_getAretopayFromSession();

		$cart_prices['payment_tax_id'] = 0;

		$cart_prices['payment_value'] = 0;



		if (!$this->checkConditions($cart, $this->_currentMethod, $cart_prices)) {

			return FALSE;

		}

		$payment_name = $this->renderPluginName($this->_currentMethod);



		$this->setCartPrices($cart, $cart_prices, $this->_currentMethod);



		return TRUE;

	}



	/*

		 * @param $plugin plugin

		 */



	protected function renderPluginName($plugin) {



		$return = '';

		$plugin_name = $this->_psType . '_name';

		$plugin_desc = $this->_psType . '_desc';

		$description = ''; 

		

		if (!empty($plugin->$plugin_desc)) {

			$description = '<span class="' . $this->_type . '_description">' . $plugin->$plugin_desc . '</span>';

		}

		$this->_getAretopayFromSession();

		$pluginName = $return . '<span class="' . $this->_type . '_name">' . $plugin->$plugin_name . '</span>' . $description;

		return $pluginName;

	}



	/**

	 * Display stored payment data for an order

	 *

	 * @see components/com_virtuemart/helpers/vmPaymentPlugin::plgVmOnShowOrderPaymentBE()

	 */

	function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_payment_id) {



		if (!($this->_currentMethod = $this->selectedThisByMethodId($virtuemart_payment_id))) {

			return NULL; // Another method was selected, do nothing

		}

		if (!($paymentTable = $this->getDataByOrderId($virtuemart_order_id))) {

			return NULL;

		}

		vmLanguage::loadJLang('com_virtuemart');



		$html = '<table class="adminlist table">' . "\n";

		$html .= $this->getHtmlHeaderBE();

		$html .= $this->getHtmlRowBE('COM_VIRTUEMART_PAYMENT_NAME', $paymentTable->payment_name);

		$html .= $this->getHtmlRowBE('VMPAYMENT_ARETOPAYT_PAYMENT_ORDER_TOTAL', $paymentTable->payment_order_total);

		$html .= $this->getHtmlRowBE('VMPAYMENT_ARETOPAY_COST_PER_TRANSACTION', $paymentTable->cost_per_transaction);

		$html .= $this->getHtmlRowBE('VMPAYMENT_ARETOPAY_COST_PERCENT_TOTAL', $paymentTable->cost_percent_total);

		$html .= '</table>' . "\n";

		return $html;

	}



	/**

	 * Reimplementation of vmPaymentPlugin::plgVmOnConfirmedOrderStorePaymentData()

	 */ 

	 

	function plgVmConfirmedOrder(VirtueMartCart $cart, $order) {	

		if (!($this->_currentMethod = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {

			return NULL; // Another method was selected, do nothing

		}

		if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {

			return FALSE;

		}

		

		if (!$this->_currentMethod->api_id) {

			JFactory::getApplication()->enqueueMessage(vmText::_('VMPAYMENT_ARETOPAY_API_ID_INVALID') , 'warning'); 

			return FALSE;

		}

		

		if (!$this->_currentMethod->api_session) {

			JFactory::getApplication()->enqueueMessage(vmText::_('VMPAYMENT_ARETOPAY_SESSION_INVALID') , 'warning'); 

			return FALSE;

		}

		

		$this->setInConfirmOrder($cart);

		$usrBT = $order['details']['BT'];

		$usrST = ((isset($order['details']['ST'])) ? $order['details']['ST'] : '');

		$session = JFactory::getSession();

		$return_context = $session->getId(); 

		

		// Set up data

		$formdata = array();

		$formdata = array_merge($this->_setBillingInformation($usrBT), $formdata);

		if (!empty($usrST)) {

			$formdata = array_merge($this->_setShippingInformation($usrST), $formdata);

		} 

		

		if($this->_currentMethod->currency_id){

			$currencyCode = $this->plgVmgetPaymentCurrency($this->_currentMethod,$this->_currentMethod->currency_id);

		}else{

			$currencyCode = $this->plgVmgetPaymentCurrency($this->_currentMethod,$order['details']['BT']->order_currency);

		}

		 

		$poststring = array();

		$poststring['currency_code'] = $currencyCode;		

		$poststring['api_id'] = $this->_currentMethod->api_id;

		$poststring['api_session'] = $this->_currentMethod->api_session;	

		$poststring['order_id'] =  $usrBT->virtuemart_order_id;

		$poststring['amount'] = $usrBT->order_total;

		$poststring['name'] =  $usrBT->first_name;

		$poststring['surname'] =  $usrBT->last_name;

		$poststring['number'] =  $this->_cc_number;

		$poststring['CVC'] = $this->_cc_cvv;

		$poststring['expiry_month'] = $this->_cc_expire_month;

		$poststring['expiry_year'] = $this->_cc_expire_year; 

		$poststring['type'] = $this->_card_type($this->validate_credit_card_number_aretopay($this->_cc_number)); 

		$poststring['address'] = $usrBT->address_1;

		$poststring['client_city'] = $usrBT->city;

		$poststring['client_country_code'] = $this->_getCountryCodeById($usrBT->virtuemart_country_id);

		$poststring['client_zip'] = $usrBT->zip;

		$poststring['client_state'] = $this->_getStateCodeById($usrBT->virtuemart_state_id);

		$poststring['client_email'] = $usrBT->email;

		$poststring['client_external_identifier'] = '';

		$poststring['client_ip'] = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';

		$poststring['client_forward_IP'] =  isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : '';

		$poststring['client_DOB'] = '';

		$poststring['client_phone'] = '';

		$poststring['token'] = '';

		$poststring['create_token'] = '';		
		$sefurl = JRoute::_('index.php?option=com_virtuemart&view=vmplg&task=pluginresponsereceived'); 
		$base_url = 'http://'.$_SERVER['HTTP_HOST'];		
		$poststring['return_url'] = $base_url.$sefurl;
		
		 

		// Prepare data that should be stored in the database

		$dbValues['order_number'] = $order['details']['BT']->order_number;

		$dbValues['virtuemart_order_id'] = $order['details']['BT']->virtuemart_order_id;

		$dbValues['payment_method_id'] = $order['details']['BT']->virtuemart_paymentmethod_id;

		$dbValues['payment_name'] = parent::renderPluginName($this->_currentMethod);

		$dbValues['cost_per_transaction'] = $this->_currentMethod->cost_per_transaction;

		$dbValues['cost_percent_total'] = $this->_currentMethod->cost_percent_total;

		$dbValues['payment_order_total'] = $totalInPaymentCurrency['value'];

		$dbValues['payment_currency'] = $payment_currency_id; 

		$this->storePSPluginInternalData($dbValues); 

		

		// send a request

		$response = $this->_sendRequest_aretopay($poststring);
		$authnet_values = array();  

		$html = $this->_handleAretopayResponse($response, $authnet_values, $order, $this->renderPluginName($this->_currentMethod));

		

	}



 



	/**

	 * @param $virtuemart_paymentmethod_id

	 * @param $paymentCurrencyId

	 * @return bool|null

	 */

	function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId) {

		

		if (!($this->_currentMethod = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {

			return NULL; // Another method was selected, do nothing

		}

		if (!$this->selectedThisElement($this->_currentMethod->payment_element)) {

			return FALSE;

		}

		 



		if (!class_exists('VirtueMartModelVendor')) {

			require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'vendor.php');

		}

		$vendorId = 1; //VirtueMartModelVendor::getLoggedVendor();

		$db = JFactory::getDBO();



		$q = 'SELECT   `currency_code_3` FROM `#__virtuemart_currencies` WHERE `virtuemart_currency_id`= "' .$paymentCurrencyId. '"';

		$db->setQuery($q);

		$paymentCurrencyCode = $db->loadResult();

		return $paymentCurrencyCode;

	} 

 

	function updateInternalOrderID($oid ,$InternalOrderID){

		$db = JFactory::getDBO();

		$q = "UPDATE `#__virtuemart_payment_plg_aretopay` SET `InternalOrderID`='$InternalOrderID' WHERE `virtuemart_order_id`='$oid'";

		$db->setQuery($q); 

		$db->query(); 

		return true;

	}



	function _getfield($string, $length) {

		if (!class_exists('shopFunctionsF')) {

			require(VMPATH_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');

		}

		return ShopFunctionsF::vmSubstr($string, 0, $length);

	}



	function _setBillingInformation($usrBT) {

		if (!class_exists('ShopFunctions'))

			require(VMPATH_ADMIN . DS . 'helpers' . DS . 'shopfunctions.php');

		$clientIp= ShopFunctions::getClientIP();

		return array(

			'x_email' => isset($usrBT->email) ? $this->_getField($usrBT->email, 100) : '', //get email

			'x_first_name' => isset($usrBT->first_name) ? $this->_getField($usrBT->first_name, 50) : '',

			'x_last_name' => isset($usrBT->last_name) ? $this->_getField($usrBT->last_name, 50) : '',

			'x_company' => isset($usrBT->company) ? $this->_getField($usrBT->company, 50) : '',

			'x_address' => isset($usrBT->address_1) ? $this->_getField($usrBT->address_1, 60) : '',

			'x_city' => isset($usrBT->city) ? $this->_getField($usrBT->city, 40) : '',

			'x_zip' => isset($usrBT->zip) ? $this->_getField($usrBT->zip, 20) : '',

			'x_state' => isset($usrBT->virtuemart_state_id) ? $this->_getField(ShopFunctions::getStateByID($usrBT->virtuemart_state_id), 40) : '',

			'x_country' => isset($usrBT->virtuemart_country_id) ? $this->_getField(ShopFunctions::getCountryByID($usrBT->virtuemart_country_id), 60) : '',

			'x_phone' => isset($usrBT->phone_1) ? $this->_getField($usrBT->phone_1, 25) : '',

			'x_fax' => isset($usrBT->fax) ? $this->_getField($usrBT->fax, 25) : '',

			'x_customer_ip' => $clientIp,

		);

	}



	function _setShippingInformation($usrST) {

		return array(

			'x_ship_to_first_name' => isset($usrST->first_name) ? $this->_getField($usrST->first_name, 50) : '',

			'x_ship_to_last_name' => isset($usrST->first_name) ? $this->_getField($usrST->last_name, 50) : '',

			'x_ship_to_company' => isset($usrST->company) ? $this->_getField($usrST->company, 50) : '',

			'x_ship_to_address' => isset($usrST->first_name) ? $this->_getField($usrST->address_1, 60) : '',

			'x_ship_to_city' => isset($usrST->city) ? $this->_getField($usrST->city, 40) : '',

			'x_ship_to_zip' => isset($usrST->zip) ? $this->_getField($usrST->zip, 20) : '',

			'x_ship_to_state' => isset($usrST->virtuemart_state_id) ? $this->_getField(ShopFunctions::getStateByID($usrST->virtuemart_state_id), 40) : '',

			'x_ship_to_country' => isset($usrST->virtuemart_country_id) ? $this->_getField(ShopFunctions::getCountryByID($usrST->virtuemart_country_id), 60) : '',

		);

	} 

	

	 

	function _sendRequest_aretopay($data) {

		$api_id 		= $data['api_id'];

		$api_session 	= $data['api_session'];

		unset($data['api_id']);

		unset($data['api_session']);

		$areto = new Areto();

		$areto->setEnvironment($api_id, $api_session);

		$response = $areto->sale_request($data);

		return $response;

	}

	 

	function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array(), &$paymentCounter) {



		$return = $this->onCheckAutomaticSelected($cart, $cart_prices);

		if (isset($return)) {

			return 0;

		} else {

			return NULL;

		}

	}

 

	protected function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name) {



		$this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);

		return TRUE;

	}



	 

	function plgVmOnShowOrderPrintPayment($order_number, $method_id) {



		return parent::onShowOrderPrint($order_number, $method_id);

	} 

	 

	function plgVmDeclarePluginParamsPaymentVM3( &$data) {

		return $this->declarePluginParams('payment', $data);

	}



	function plgVmSetOnTablePluginParamsPayment($name, $id, &$table) {



		return $this->setOnTablePluginParams($name, $id, $table);

	} 

	

	function _getAretopayFromSession() {		

		$session = JFactory::getSession();

		$aretopaySession = $session->get('aretopay', 0, 'vm');



		if (!empty($aretopaySession)) {

			$aretopayData = (object)json_decode($aretopaySession,true); 

			$this->_cc_name =  $aretopayData->cc_name;

			$this->_cc_number =  $aretopayData->cc_number;

			$this->_cc_cvv =  $aretopayData->cc_cvv;

			$this->_cc_expire_month = $aretopayData->cc_expire_month;

			$this->_cc_expire_year = $aretopayData->cc_expire_year;

			$this->_cc_valid = $aretopayData->cc_valid;

		}

	}

	

	function _setAretopayIntoSession ()

	{

		

		

		$session = JFactory::getSession();

		$sessionAretopay = new stdClass();

		// card information

		//$sessionAretopay->cc_type = $this->_cc_type;

		$sessionAretopay->cc_name =  $this->_cc_name;

		$sessionAretopay->cc_number = $this->_cc_number;

		$sessionAretopay->cc_cvv = $this->_cc_cvv;

		$sessionAretopay->cc_expire_month = $this->_cc_expire_month;

		$sessionAretopay->cc_expire_year = $this->_cc_expire_year;

		$sessionAretopay->cc_valid = $this->_cc_valid;

		$session->set('aretopay', json_encode($sessionAretopay), 'vm');

	}

	

	function _getStateCodeById($id){

		$db = JFactory::getDBO();

		$q = 'SELECT   `state_2_code` FROM `#__virtuemart_states` WHERE `virtuemart_state_id`= "' .$id. '"';

		$db->setQuery($q);

		$paymentCurrencyCode = $db->loadResult();

		return $paymentCurrencyCode;

	}

	

	function _getOrderIdByInternalOderid($id){

		$db = JFactory::getDBO();

		$q = 'SELECT  `virtuemart_order_id` FROM `#__virtuemart_payment_plg_aretopay` WHERE `InternalOrderID`= "' .$id. '"';

		$db->setQuery($q);

		$id = $db->loadResult();

		return $id;

	}

	

	function _getCountryCodeById($id){

		$db = JFactory::getDBO();

		$q = 'SELECT   `country_2_code` FROM `#__virtuemart_countries` WHERE `virtuemart_country_id`= "' .$id. '"';

		$db->setQuery($q);

		$paymentCurrencyCode = $db->loadResult();

		return $paymentCurrencyCode;

	}

	

	function _finalRedirect($responsepredirect){	

		 

		if(isset($responsepredirect['Redirect']['RedirectLink']) && !empty($responsepredirect['Redirect']['RedirectLink'])){

			$url = urldecode($responsepredirect['Redirect']['RedirectLink']); 

			$redirect_arr = array(

				'PaReq'=>$responsepredirect['Redirect']['Parameters']['PaReq'], 

				'MD'=>$responsepredirect['Redirect']['Parameters']['MD'], 

				'TermUrl'=>$responsepredirect['Redirect']['Parameters']['TermUrl'] 

			);

						

			$method = !empty($responsepredirect['Redirect']['Parameters']['Method']) ? $responsepredirect['Redirect']['Parameters']['Method'] : 'POST';

			$params = $responsepredirect['Redirect']['Parameters'];



			echo '<br /><strong>Redirect to payment gateway...</strong>';

			echo sprintf('<form id="areto_checkout" action="%s" method="%s">', $url, $method);

			foreach ($params as $key => $value) {

				echo sprintf('<input type="hidden" name="%s" value="%s" />', $key, $value);

			}

			echo '</form>';

			echo '<script>document.getElementById(\'areto_checkout\').submit();</script>';

			exit;

		}else{			

			return false;

		}

		

	}

	function _handleAretopayResponse($responsepredirect,$submitted_values, $order, $payment_name) {		

		if(isset($responsepredirect['Result']['Code']) && $responsepredirect['Result']['Code'] == 4){	

			$InternalOrderID = isset($responsepredirect['Body']['InternalOrderID']) ? $responsepredirect['Body']['InternalOrderID'] : '';

			$orderid = $order['details']['BT']->virtuemart_order_id;

			$this->updateInternalOrderID($orderid,$InternalOrderID);

			$response = $this->_finalRedirect($responsepredirect); 

		}else if(isset($responsepredirect['Result']['Code']) && $responsepredirect['Result']['Code'] == 1){	

			 if (!class_exists('VirtueMartCart')) require(VMPATH_SITE . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'cart.php');

				

				$virtuemart_order_id = $order['details']['BT']->virtuemart_order_id;

				$order = VirtueMartModelOrders::getOrder($virtuemart_order_id);

				

				

				$db = JFactory::getDBO();

				$query = 'SHOW COLUMNS FROM `' . $this->_tablename . '` ';

				$db->setQuery($query);

				$columns = $db->loadColumn(0);

				

				$iod = (isset($responsepredirect['Body']['InternalOrderID'])) ? $responsepredirect['Body']['InternalOrderID'] : '';

				$response_fields['virtuemart_order_id'] = $virtuemart_order_id;

				$response_fields['invoice_number'] = $iod; 



				$this->storePSPluginInternalData($response_fields, 'virtuemart_order_id', TRUE);



				$html = '<table class="adminlist table">' . "\n";

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAY_PAYMENT_NAME', 'Credit/debit cards');

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAY_PAYMENT_STATUS', 'Accepted');

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAYT_ORDER_NUMBER',$order['details']['BT']->order_number);

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAYT_AMOUNT',number_format($order['details']['BT']->order_total,2));

				

				if ($iod) {

					$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAYT_RESPONSE_TRANSACTION_ID',$iod);

				}

				$html .= '</table>' . "\n"; 

				

				$modelOrder = VmModel::getModel('orders');

				$order['order_status'] = 'C';

				$order['customer_notified'] = 1;

				$order['comments'] = '';

				$modelOrder->updateStatusForOneOrder($order['details']['BT']->virtuemart_order_id, $order, TRUE); 

				

				$cart = VirtueMartCart::getCart(); 

				$cart->emptyCart();

				$this->_clearAretopaySession();

				vRequest::setVar('html', $html); 

			 

			 

		} else{

			$this->approved = FALSE;

			$this->error = TRUE;

			$html = vmText::sprintf('VMPAYMENT_ARETOPAY_ERROR', $responsepredirect['Result']['Description'], $AretopayResponse['Result']['Code']) . "<br />";

			vRequest::setVar('html', $html);

		}

		

	}

	

	

	function plgVmOnPaymentResponseReceived(&$html) {	

		$iod = isset($_REQUEST['iod']) ? $_REQUEST['iod'] : '';

		if($iod){

			$virtuemart_order_id =  $this->_getOrderIdByInternalOderid($iod);

			if (!$virtuemart_order_id) {

				 $this->approved = FALSE;

				$this->error = TRUE;

				$html = vmText::sprintf('VMPAYMENT_ARETOPAY_ERROR','', '') . "<br />";

				vRequest::setVar('html', $html); 

			}else{

				if (!class_exists('VirtueMartCart')) require(VMPATH_SITE . DIRECTORY_SEPARATOR . 'helpers' . DIRECTORY_SEPARATOR . 'cart.php');

				

				

				$order = VirtueMartModelOrders::getOrder($virtuemart_order_id);

				

				

				$db = JFactory::getDBO();

				$query = 'SHOW COLUMNS FROM `' . $this->_tablename . '` ';

				$db->setQuery($query);

				$columns = $db->loadColumn(0);

		  

				$response_fields['virtuemart_order_id'] = $virtuemart_order_id;

				$response_fields['invoice_number'] = $iod; 



				$this->storePSPluginInternalData($response_fields, 'virtuemart_order_id', TRUE);



				$html = '<table class="adminlist table">' . "\n";

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAY_PAYMENT_NAME', 'Credit/debit cards');

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAY_PAYMENT_STATUS', 'Accepted');

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAYT_ORDER_NUMBER',$order['details']['BT']->order_number);

				$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAYT_AMOUNT',number_format($order['details']['BT']->order_total,2));

				

				if ($iod) {

					$html .= $this->getHtmlRow('VMPAYMENT_ARETOPAYT_RESPONSE_TRANSACTION_ID',$iod);

				}

				$html .= '</table>' . "\n"; 

				

				$modelOrder = VmModel::getModel('orders');

				$order['order_status'] = 'C';

				$order['customer_notified'] = 1;

				$order['comments'] = '';

				$modelOrder->updateStatusForOneOrder($order['details']['BT']->virtuemart_order_id, $order, TRUE); 

				

				$cart = VirtueMartCart::getCart(); 

				$cart->emptyCart();

				$this->_clearAretopaySession();

				vRequest::setVar('html', $html); 

			}

		}else{

			$html = vmText::sprintf('VMPAYMENT_ARETOPAY_ERROR','','') . "<br />";

			vRequest::setVar('html', $html); 

		}

		

	}

	

	function _handleAretopayPaymentCancel($virtuemart_order_id, $html) {



		if (!class_exists('VirtueMartModelOrders')) {

			require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');

		}

		$modelOrder = VmModel::getModel('orders'); 

		$mainframe = JFactory::getApplication();

		vmWarn($html);

		$mainframe->redirect(JRoute::_('index.php?option=com_virtuemart&view=cart&task=editpayment', FALSE), vmText::_('COM_VIRTUEMART_CART_ORDERDONE_DATA_NOT_VALID'));

	}

	

	function _clearAretopaySession() {



		$session = JFactory::getSession();

		$session->clear('aretopay', 'vm');

	}

	

	

}



// No closing tag

